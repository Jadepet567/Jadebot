# frozen_string_literal: true

# Webhook support for discordrb
module Discordrb
  module Webhooks
    # The current version of discordrb-webhooks.
    VERSION = '3.2.0.1'.freeze
  end
end
