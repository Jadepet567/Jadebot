# frozen_string_literal: true

# Discordrb and all its functionality, in this case only the version.
module Discordrb
  # The current version of discordrb.
  VERSION = '3.2.1'.freeze
end
